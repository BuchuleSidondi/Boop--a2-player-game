package com.example.boop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class winner extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winner);

        Button playagain=findViewById(R.id.button3);
        Intent intent;
        if(getIntent()!=null)
        intent=getIntent();
        else return;
        TextView winner=findViewById(R.id.winnerTxrView);
        String extra= intent.getStringExtra("winner");
        winner.setText(extra);

        playagain.setOnClickListener(e->
        {  Intent intent1=new Intent(this,MainActivity.class);
           startActivity(intent1);
        });
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        TextView winner=findViewById(R.id.winnerTxrView);
        winner.setText(savedInstanceState.getString("winner"));

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState)
    {
        super.onSaveInstanceState(outState);
        TextView winner=findViewById(R.id.winnerTxrView);
        outState.putString("winner",winner.getText().toString());
    }
}