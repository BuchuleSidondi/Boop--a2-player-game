package com.example.boop;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.List;

public class Controller
  {
      Context context;
      Resources resources;
      ConstraintLayout ancestor;
      TableRow player1row;
      TableRow player2row;
      List<Cat>catlist=new ArrayList<>();
      public static Cat clicked;
      public static boolean clickedcat=false;
      boolean player1turn=true;
      TableLayout tableLayout;
      TextView playerturn;
      ArrayList<ArrayList<CardView>> options;
      List<String> optionsstring=new ArrayList<>();
      CheckBox sound;
      MediaPlayer mediaPlayer;
      MediaPlayer playgamesong;
      CardView clickcard;


      public Controller(Context context, ConstraintLayout constraintLayout)
     {
         this.context = context;
         ancestor=constraintLayout;
         resources=context.getResources();

         player1row=constraintLayout.findViewById(R.id.player1row);
         player2row=constraintLayout.findViewById(R.id.player2row);
         tableLayout=constraintLayout.findViewById(R.id.playView);
         playerturn=constraintLayout.findViewById(R.id.playTurn);
         sound=constraintLayout.findViewById(R.id.soundoon);
         mediaPlayer=MediaPlayer.create(context,R.raw.meow2);
         playgamesong=MediaPlayer.create(context,R.raw.catsong);
         addCats();
         //sound.setChecked(true);
         //catsclickEvent();
         setonClick();
         offsong();

     }

      private void offsong()
      {
          sound.setOnClickListener(e->{
              if(sound.isChecked())
              {
               playgamesong.start();
              }
                if(!sound.isChecked())
                {playgamesong.stop();}
          });
      }


      public void addCats()
     {
         for(int i=0;i<=7;i++)
         {   Cat grey=new Cat(context,true);
             grey.setTag(10);
             catlist.add(grey);
             player1row.addView(grey);
         }

         for(int i=0;i<=7;i++)
         {   Cat yellow=new Cat(context,false);
             yellow.setTag(20);
             catlist.add(yellow);
             player2row.addView(yellow);
         }

     }

      public void setonClick() //for grid
      {
          for(int i=0;i<tableLayout.getChildCount();i++)
          {
              TableRow tableRow = (TableRow) tableLayout.getChildAt(i);
              tableRow.setTag(i);

              for(int j=0;j<tableRow.getChildCount();j++)
              {
                  CardView button = (CardView) tableRow.getChildAt(j);

                  //save r and c coordinate of button

                  int [] pos={i,j,0};

                  button.setTag(pos); //belong to no one

                  button.setOnClickListener(e->
                  {
                      if(clickedcat||(player1row.getChildCount()>0||player2row.getChildCount()>0))
                      {if(clicked!=null){
                          if((clicked.getTag().equals(10)&&player1turn)||(clicked.getTag().equals(20)&&!player1turn))
                          {   addCat(clicked, button);

                          }}

                          else
                          {
                              if(player1row.getChildCount()==0||player2row.getChildCount()==0)
                          {clickcard=button;
                           checkemptyrows();}
                          else
                          {Toast.makeText(context, R.string.notyourturn,Toast.LENGTH_SHORT).show();}}
                      } 
                      
                      else
                      {Toast.makeText(context, R.string.nocat,Toast.LENGTH_SHORT).show();}

                  });

              }
          }
      }

      private void addCat(ImageButton cat, CardView button)
      {
          if(button.getChildCount()>0)
          {return;}
          TableRow catplace = (TableRow) cat.getParent();
          catplace.removeView(cat);
          cat.setLayoutParams(new ViewGroup.LayoutParams(
                  ViewGroup.LayoutParams.MATCH_PARENT, // Width
                  ViewGroup.LayoutParams.MATCH_PARENT  // Height
          ));
          button.addView(cat);

          int [] tag=(int [])button.getTag();
          if(player1turn){button.setTag(new int[]{tag[0], tag[1], 1});}
          else button.setTag(new int[]{tag[0], tag[1], 2});
          options=new ArrayList<>();
          checkrows(button);
          clicked=null;
          clickedcat=false;
          if(player1row.getChildCount()==0||player2row.getChildCount()==0)
          Toast.makeText(context,"Click kitten to upgrade",Toast.LENGTH_SHORT).show();
          changeTextview();

      }

      private void checkemptyrows() {
         if(player1row.getChildCount()==0){
             if(clickcard.getChildCount()>0)
             {
                 Cat feline=(Cat)clickcard.getChildAt(0);
                 if(feline.Player1)
                 {
                     if(!feline.iscat)
                     {feline.upgrade();
                     clickcard.removeView(feline);
                     player1row.addView(feline);}
                     else {Toast.makeText(context,"Make better life choices",Toast.LENGTH_SHORT).show();}
                 }
                 else {Toast.makeText(context,"Wrong cat",Toast.LENGTH_SHORT).show();}

             }
             Toast.makeText(context,"Nothing here",Toast.LENGTH_SHORT).show();
         }

         else if(player2row.getChildCount()==0){
             if(clickcard.getChildCount()>0)
             {
                 Cat feline=(Cat)clickcard.getChildAt(0);
                 if(!feline.Player1)
                 {
                     if(!feline.iscat)
                     {feline.upgrade();
                         clickcard.removeView(feline);
                         player2row.addView(feline);}
                     else {Toast.makeText(context,"Make better life choices",Toast.LENGTH_SHORT).show();}
                 }
                 else {Toast.makeText(context,"Wrong cat",Toast.LENGTH_SHORT).show();}
             }
             else
             Toast.makeText(context,"Nothing here",Toast.LENGTH_SHORT).show();
         }

         clickcard=null;
      }

      public ArrayList<CardView> getRow(CardView main, int [] pos, int [] pos1, TableRow tr1, TableRow tr2, boolean found)
      {
          int id= context.getResources().getIdentifier("_"+pos[0]+pos[1],"id", context.getPackageName());
          int id1; CardView button1=null;
          if(tr2!=null) {
              id1 = context.getResources().getIdentifier("_" + pos1[0] + pos1[1], "id", context.getPackageName());
              button1=tr2.findViewById(id1);
          }
            CardView button =tr1.findViewById(id);
            ArrayList <CardView> cats= new ArrayList<>(); cats.add(main);
            cats.add(button);cats.add(button1);

            if(button.getChildCount() > 0&&button1 != null)
            {
                if (button1.getChildCount()==0)
                {
                    Cat mainn=((Cat)main.getChildAt(0));
                    Cat remove=(Cat) button.getChildAt(0);
                    if(mainn.iscat||(!remove.iscat))
                    {
                        button.removeView(remove);
                        button1.addView(remove);
                    }



                }
            }

            else if(button.getChildCount()>0 && button1==null)

            {     Cat mainn=((Cat)main.getChildAt(0));  Cat remove=(Cat) button.getChildAt(0);
                //Cat remove=(Cat) button.getChildAt(0);
                if(mainn.iscat||(!remove.iscat))
                {
                    button.removeView(remove);
                    if(remove.Player1)
                        player1row.addView(remove,new TableRow.LayoutParams(60, 100));
                    else player2row.addView(remove,new TableRow.LayoutParams(60, 100));
                }


                //button.removeViewAt(0);

            }
            return cats;
      }

      public void checkbuttons(ArrayList <CardView> cards)
      {
          int p1catcount=0,p2catcount=0;int kittensp1=0,kittensp2=0;
          boolean nonull=true; boolean kittensprez=false; boolean mix=false;

          for(int i=0;i<cards.size();i++)
          {
              if((cards.get(i))!=null)
              {
                  if((cards.get(i)).getChildCount()>0)
                  {
                      Cat cat=(Cat) (cards.get(i)).getChildAt(0);
                      //for the wins
                      if(cat.iscat&&cat.Player1)
                      {p1catcount++;}

                      else if(!(cat.Player1) && cat.iscat)
                      {p2catcount++;}
                      //if no win ?

                      if(!cat.iscat&&cat.Player1)
                      { kittensprez=true;
                          kittensp1++;}

                      if(!cat.iscat&&!cat.Player1){
                          kittensprez=true;
                          kittensp2++;
                      }

                  }
                  else nonull=false;
              }
              else nonull=false; //boop possible

          }
          //region Handle wins
          if(p1catcount==3&&nonull)
          {
              Intent intent = new Intent(context,winner.class);
              intent.putExtra("winner",context.getString(R.string.p1winner));
              context.startActivity(intent);
          }

          else if (p2catcount==3&&nonull)
          {
              Intent intent = new Intent(context,winner.class);
              intent.putExtra("winner",context.getString(R.string.p2winner));
              context.startActivity(intent);
          }
          //endregion


          else if(nonull&&kittensprez)// no win
          {
              if(p2catcount==0&&kittensp2==0) //can replace all with cats
              {options.add(cards);}

              else if(p1catcount==0&&kittensp1==0)
              {options.add(cards);
              }

          }
      }

      @SuppressLint("SuspiciousIndentation")
      public void inspectlists(ArrayList<ArrayList<CardView>> cards)
      {
          for (ArrayList<CardView> cats: cards)
          {
              checkbuttons(cats); //add all rows
          }

          //use options array replace kittens with cats if need be, give users choices
          if(options.size()==1) //only one replacement to do
          {
              if(sound.isChecked())
              mediaPlayer.start();
              ArrayList <CardView> option=options.get(0);
              removeViews(option);
          }

          else
          {
              for(int i =0;i<options.size();i++)
              { StringBuilder option= new StringBuilder();
                  for(CardView card: options.get(i)) //take the tag of each
                  {
                      int [] tag=(int[])card.getTag();

                      option.append(tag[0]).append(",").append(tag[1]).append(" ");
                  }
                  optionsstring.add(option.toString());
              }

              showDynamicMenu(tableLayout,optionsstring);

          }

      }

      public void checkrows(CardView gridbutton)
      {
          ArrayList<ArrayList<CardView>> lists = new ArrayList<>();
          int [] pos= (int[]) gridbutton.getTag();

          boolean found=false;
          //region adresses for diagonal neighbours
          int[] posup={pos[0]-1,pos[1]+1}; //1 up , 1 right

          int[] posup1={pos[0]-2,pos[1]+2}; //2 up , 2 right

          int [] posup2 ={pos[0]-1,pos[1]-1}; //1 up, 1 left

          int [] posup3={pos[0]-2,pos[1]-2}; //2 up, 2 left

          int [] posdown={pos[0]+1,pos[1]+1}; //1 down, 1 right

          int[] posdown1={pos[0]+2,pos[1]+2}; //2 down , 2 right

          int [] posdown2={pos[0]+1,pos[1]-1}; //1 down, 1 left

          int [] posdown3={pos[0]+2,pos[1]-2}; //2 down, 2 left

          int[] posupp={pos[0]-1,pos[1]}; //1 up

          int[] posupup={pos[0]-2,pos[1]}; //2 up

          int [] posdownn ={pos[0]+1,pos[1]}; //1 down

          int [] posdownn2={pos[0]+2,pos[1]}; //2 down

          int row=pos[0];
          int col=pos[1];

          //endregion

          // region up, down and diagonal checks
          if(row-1>=0) //check rows above
          {   TableRow tr2=null;
              TableRow tr1=tableLayout.findViewWithTag(row-1); //1 row up
              if(row-2>=0)
              {tr2=tableLayout.findViewWithTag(row-2);} //2 rows up


              if(col+1<6) //check right
              {
                  ArrayList <CardView> roww=getRow(gridbutton,posup,posup1,tr1,tr2,found);
                  if(roww!=null)
                      lists.add(roww);
              }

              if(col-1>=0) //check left
              {   ArrayList <CardView> roww=getRow(gridbutton,posup2,posup3,tr1,tr2,found);
                  if(roww!=null)
                      lists.add(roww);
              }

              //1 up 2 up
              ArrayList<CardView> roww=getRow(gridbutton,posupp,posupup,tr1,tr2,found);
              if(roww!=null)
                  lists.add(roww);

          }


          if(row+1<6) //check rows below
          {
              TableRow tr1=tableLayout.findViewWithTag(row+1); //1 row down
              TableRow tr2=null;

              if(row+2<6)
                  tr2=tableLayout.findViewWithTag(row+2); //2 rows down

              if(col+1<6) //check right
              {   ArrayList<CardView> roww=getRow(gridbutton, posdown,posdown1,tr1,tr2,found);
                  if(roww!=null)
                      lists.add(roww);
              }

              if(col-1>=0) //check left
              {   ArrayList<CardView>roww=getRow(gridbutton,posdown2,posdown3,tr1,tr2,found);
                  if(roww!=null)
                      lists.add(roww);

              }
              ArrayList<CardView>roww=getRow(gridbutton,posdownn,posdownn2,tr1,tr2,found);
              if(roww!=null)
                  lists.add(roww);
          }

          //endregion

          //region straight checks

          int [] posleft={pos[0],pos[1]-1}; //1 left

          int [] posleft2={pos[0],pos[1]-2}; //2 left

          int [] posright={pos[0],pos[1]+1}; //1 right

          int [] posright2={pos[0],pos[1]+2}; //2 right
          // endregion

          if(col+1<6) //check right side
          {
              TableRow tableRow=tableLayout.findViewWithTag(row);
              ArrayList<CardView> roww=getRow(gridbutton,posright,posright2,tableRow,tableRow,found);
              lists.add(roww);
          }

          if(col-1>=0) //check left side
          {
              TableRow tableRow=tableLayout.findViewWithTag(row);
              ArrayList<CardView> roww=getRow(gridbutton,posleft,posleft2,tableRow,tableRow,found);
              lists.add(roww);
          }

          inspectlists(lists);
      }

      public void changeTextview()
      {
          if(player1turn) //If p1 didn't get a point
          {
              player1turn=false;
              playerturn.setText(R.string.p2turn);

          }
          else
          {
              player1turn=true;
              playerturn.setText(R.string.p1turn);

          }
      }

      private void showDynamicMenu(View v, List<String> menuItems)
      {

          PopupMenu popupMenu = new PopupMenu(context, v);

          // Inflate an empty menu (or you can use your existing menu if needed)
          MenuInflater inflater = popupMenu.getMenuInflater();
          inflater.inflate(R.menu.empty_menu, popupMenu.getMenu());


          // Add menu items programmatically based on the List<String> menuItems
          for (int i = 0; i < menuItems.size(); i++) {
              popupMenu.getMenu().add(Menu.NONE, i, Menu.NONE, menuItems.get(i));
          }

          // Set a click listener for the menu items
          popupMenu.setOnMenuItemClickListener(item -> {
              // Handle menu item clicks here based on item.getItem-title()
              String title= (String) item.getTitle();

              for(int i =0;i<options.size();i++)
              {
                  StringBuilder option= new StringBuilder();
                  for(CardView card: options.get(i))
                  {
                      int [] tag=(int[])card.getTag();
                      option.append(tag[0]).append(", ").append(tag[1]).append(" ");
                  }

                  if(option.toString().equals(title))
                  {   removeViews(options.get(i));
                      break;
                  }

              }
              return true;
          });

          // Show the popup menu

          popupMenu.show();
      }

      public void removeViews(ArrayList<CardView>option)
      {
          for (CardView cardd:option)
          {   Cat cat =(Cat) cardd.getChildAt(0);
              if(!cat.iscat)
              {cat.upgrade();}
              cardd.removeAllViews();
              if(cat.Player1)
              {player1row.addView(cat,new TableRow.LayoutParams(60,100));
              }
              else player2row.addView(cat,new TableRow.LayoutParams(60,100));

          }

      }

      public void save(Bundle outState)
      {   outState.putBoolean("Turn",player1turn);

          int k=0;

          for(int i=0;i<player1row.getChildCount();i++)
          {
              Cat cat=(Cat)player1row.getChildAt(i);
              k+=1;
              if(cat!=null)
              {
                  if(cat.iscat){

                      outState.putInt(String.valueOf(k), 1);
                  }

                  else outState.putInt(String.valueOf(k), 2);
              }
              else
              {outState.putInt(String.valueOf(k),0);}
          }
          k=8; //must go to 8 or else will add more cats to p1 row and less to p2 row if k<k-8 is skipped above
          // ie when there are less than 8 cats for p1
          for (int i=0;i<player2row.getChildCount();i++)
          {
              Cat cat=(Cat)player2row.getChildAt(i);
              k+=1;
              if(cat!=null)
              {
                  if(cat.iscat)
                  outState.putInt(String.valueOf(k), 1);
                  else outState.putInt(String.valueOf(k), 2);
              }
              else
              {outState.putInt(String.valueOf(k),0);}
          }

          int t=17;

          for(int i=0;i<tableLayout.getChildCount();i++)
          {
              TableRow tableRow = (TableRow) tableLayout.getChildAt(i);

              for(int j=0;j<tableRow.getChildCount();j++)
              {   CardView cardView= (CardView) tableRow.getChildAt(j);
                  StringBuilder stringBuilder=new StringBuilder();

                  if(cardView.getChildCount()>0)
                  {
                      Cat thiscat=(Cat) cardView.getChildAt(0);

                      if(thiscat.Player1)
                      {stringBuilder.append("1,"); //for player one
                      }
                      else stringBuilder.append("2,");

                      if(thiscat.iscat){
                          stringBuilder.append("1");
                      }
                      else stringBuilder.append("2");
                  }
                  else
                    stringBuilder.append("0");

                  outState.putString(String.valueOf(t),stringBuilder.toString());
                  t+=1;
              }

          }
      }

      public void restore(Bundle preferences)
      {
          boolean player1turnn=preferences.getBoolean("Turn");

          if(player1turnn)
          {   player1turn=true;
              playerturn.setText(R.string.p1turn);
          }
          else { player1turn=false;
                 playerturn.setText(R.string.p2turn);}

          player1row.removeAllViews();
          player2row.removeAllViews();

          for(int i=1;i<=8;i++)
         { int cat=preferences.getInt(String.valueOf(i),3);
            if(cat==1)
            {
                Cat newcat=new Cat(context,true);
                newcat.upgrade();
                newcat.setTag(10);
                player1row.addView(newcat,new TableRow.LayoutParams(60, 100));
            }
            else if(cat==2){
                Cat newcat=new Cat(context,true);
                newcat.setTag(10);
                player1row.addView(newcat,new TableRow.LayoutParams(60, 100));
            }
         }

          for(int i=9;i<=16;i++)
          {   int cat=preferences.getInt(String.valueOf(i),3);

              if(cat==1){
                  Cat newcat=new Cat(context,false);
                  newcat.upgrade();
                  newcat.setTag(20);
                  player2row.addView(newcat,new TableRow.LayoutParams(60, 100));
              }
              else if(cat==2){
                  Cat newcat=new Cat(context,false);
                  newcat.setTag(20);
                  player2row.addView(newcat,new TableRow.LayoutParams(60, 100));
              }
          }

          int t=16;
          for(int i=0;i<tableLayout.getChildCount();i++)
          {
              TableRow tableRow = (TableRow) tableLayout.getChildAt(i);

              for(int j=0;j<tableRow.getChildCount();j++)
              {   CardView cardView= (CardView) tableRow.getChildAt(j);
                  t+=1;
                  String stringg=preferences.getString(String.valueOf(t), "niks");
                  if(!stringg.equals("0"))
                  { String [] strings=stringg.split(",");
                      Cat cat;
                      if(strings.length>1){
                          if(strings[0].equals("1"))//player 1
                          {
                              cat=new Cat(context,true);
                              if(strings[1].equals("1")){
                                  cat.upgrade();
                              }
                              cardView.addView(cat,new ViewGroup.LayoutParams(
                                      ViewGroup.LayoutParams.MATCH_PARENT, // Width
                                      ViewGroup.LayoutParams.MATCH_PARENT));
                          }

                          else
                          { cat=new Cat(context,false);
                            if(strings[1].equals("1")){
                              cat.upgrade();}
                            cardView.addView(cat,new ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT, // Width
                                    ViewGroup.LayoutParams.MATCH_PARENT));
                          }
                      }

                  }


              }

          }

      }

  }
