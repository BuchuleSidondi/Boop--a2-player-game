package com.example.boop;

import android.media.Image;
import android.widget.ImageView;

public class Player {

    int playerno;
    ImageView image;

    public Player(int playerno)
    {
        this.playerno=playerno;
        if(playerno==1) {
            this.image.setImageResource(R.drawable.kittengrey);
        }
        else this.image.setImageResource(R.drawable.kittenorange);
    }
}
