package com.example.boop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;

public class Splash extends AppCompatActivity {
    Handler handler=new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        MediaPlayer mediaPlayer=MediaPlayer.create(this,R.raw.meow);
        mediaPlayer.start();
        handler.postDelayed(()->{
            Intent intent = new Intent(this, startgame.class);
            startActivity(intent);
            finish();
        },2000);
        //


    }
}