package com.example.boop;

import android.content.Context;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TableRow;

public class Cat extends androidx.appcompat.widget.AppCompatImageButton
{
    boolean Player1;
    boolean iscat;

    public Cat(Context context, boolean isplayer1)
    {
        super(context);
        Player1 = isplayer1;
        iscat=false;

        //Set the width and height of the ImageView
        TableRow.LayoutParams params = new TableRow.LayoutParams(60, 100); // Adjust the width and height as needed

        setLayoutParams(params);
        setBackgroundColor(Color.TRANSPARENT);

        if(isplayer1)
        {
           setImageResource(R.drawable.kittengrey);
        }

        else setImageResource(R.drawable.kittenorange);

        catsclickEvent();
    }

    public void upgrade()
    {
        if (Player1){
            iscat=true;
            setImageResource(R.drawable.catgrey);
        }
        if(!Player1){iscat=true;
            setImageResource(R.drawable.catorange);
        }
    }

    public void catsclickEvent()
    {
        //assign the cat clicked to clicked then add
            setOnClickListener(e->
            {   Controller.clicked=this;
                Controller.clickedcat=true;
            });
    }


}